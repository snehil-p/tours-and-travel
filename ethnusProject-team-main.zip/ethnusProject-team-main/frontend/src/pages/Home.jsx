import React from 'react'
import '../styles/home.css'
import { Container, Row, Col, CardSubtitle } from 'reactstrap'
import heroImg from '../assets/images/hero-img01.jpg'
import heroImg02 from '../assets/images/hero-img02.jpg'
import heroVideo from '../assets/images/hero-video.mp4'
import worldImg from '../assets/images/world.png'
import experienceImg from '../assets/images/experience.png'

import Subtitle from './../shared/subtitle'
import SearchBar from './../shared/SearchBar'
import ServiceList from '../services/ServiceList'
import FeaturedTourList from '../components/Featured-tours/FeaturedTourList'
import MasonryImagesGallery from '../components/Image-gallery/MasonryImagesGallery'
import Testimonials from '../components/Testimonial/Testimonials'
import NewsLetter from '../shared/Newsletter'

const Home = () => {
   return <>
      {/* ========== HERO SECTION ========== */}
      <section>
         <Container>
            <Row>
               <Col lg='6'>
                  <div className="hero__content">
                     <div className="hero__subtitle d-flex align-items-center">
                        <Subtitle subtitle={'Ready, Set, Explore!'} />
                        <img src={worldImg} alt="" />
                     </div>
                     <h1>Journey sparks<span className='hightlight'> inspiration</span></h1>
                     <p>
                     Travel is more than just a physical journey; it's a voyage of the mind and soul. 
                     Stepping into new cultures, exploring unfamiliar landscapes, and meeting diverse people ignite creativity and broaden perspectives. 
                     Each trip becomes a treasure trove of experiences, fueling new ideas and inspiring fresh ways of thinking.
                     Whether you're wandering through ancient cities, hiking breathtaking trails, or simply savoring local delicacies, travel rejuvenates the spirit and nurtures the creative soul.
                     Embrace the adventure and let every destination become a canvas for your imagination.
                     </p>
                  </div>
               </Col>

               <Col lg='2'>
                  <div className="hero__img-box">
                     <img src={heroImg} alt="" />
                  </div>
               </Col>
               <Col lg='2'>
                  <div className="hero__img-box hero__video-box mt-4">
                     <video src={heroVideo} alt="" controls />
                  </div>
               </Col>
               <Col lg='2'>
                  <div className="hero__img-box mt-5">
                     <img src={heroImg02} alt="" />
                  </div>
               </Col>

            </Row>
         </Container>
      </section>
      {/* ============================================================== */}

      {/* ==================== HERO SECTION START ====================== */}
      <section>
         <Container>
            <Row>
               <Col lg='3'>
                  <h5 className="services__subtitle">What We Bring to You</h5>
                  <h2 className="services__title">Experience the Best with Us</h2>
               </Col>
               <ServiceList />
            </Row>
         </Container>
      </section>

      {/* ========== FEATURED TOUR SECTION START ========== */}
      <section>
         <Container>
            <Row>
               <Col lg='12' className='mb-5'>
                  <Subtitle subtitle={'Discover'} />
                  <h2 className='featured__tour-title'>Exclusive Journeys</h2>
                  <p>
                     "Discover unforgettable tours crafted to immerse you in each destination's heart. 
                     Led by expert guides, our excursions bring culture, history, and natural beauty to life. 
                     Whether it's ancient landmarks, scenic landscapes, or vibrant markets, each tour promises extraordinary experiences and lasting memories."
                  </p>
               </Col>
               <FeaturedTourList />
            </Row>
         </Container>
      </section>
      {/* ========== FEATURED TOUR SECTION END =========== */}

      {/* ========== EXPERIENCE SECTION START ============ */}
      <section>
         <Container>
            <Row>
               <Col lg='6'>
                  <div className="experience__content">
                     <Subtitle subtitle={'Experience'} />
                     <h2>Let our seasoned expertise enhance your experience.</h2>
                     <p>Discover the difference our seasoned expertise makes. 
                        With years of industry knowledge, we're dedicated to elevating your experience with tailored solutions and unparalleled service. 
                        Whether you're planning a journey, seeking advice, or requiring specialized assistance, our commitment to excellence ensures every interaction is insightful, efficient, and enriching. 
                        Trust in our expertise to enhance your experience and exceed your expectations at every turn.
                     </p>
                  </div>

                  <div className="counter__wrapper d-flex align-items-center gap-5">
                     <div className="counter__box">
                        <span>12k+</span>
                        <h6>Successful trips</h6>
                     </div>
                     <div className="counter__box">
                        <span>2k+</span>
                        <h6>Regular clients</h6>
                     </div>
                     <div className="counter__box">
                        <span>15</span>
                        <h6>Years experience</h6>
                     </div>
                  </div>
               </Col>
               <Col lg='6'>
                  <div className="experience__img">
                     <img src={experienceImg} alt="" />
                  </div>
               </Col>
            </Row>
         </Container>
      </section>
      {/* ========== EXPERIENCE SECTION END ============== */}

      {/* ========== GALLERY SECTION START ============== */}
      <section>
         <Container>
            <Row>
               <Col lg='12'>
                  <Subtitle subtitle={'Gallery'} />
                  <h2 className="gallery__title">Visit our customers tour gallery</h2>
               </Col>
               <Col lg='12'>
                  <MasonryImagesGallery />
               </Col>
            </Row>
         </Container>
      </section>
      {/* ========== GALLERY SECTION END ================ */}

      {/* ========== TESTIMONIAL SECTION START ================ */}
      <section>
         <Container>
            <Row>
               <Col lg='12'>
                  <Subtitle subtitle={'Followers Cherish'} />
                  <h2 className="testimonial__title">Voices of Our Customers</h2>
               </Col>
               <Col lg='12'>
                  <Testimonials />
               </Col>
            </Row>
         </Container>
      </section>
      {/* ========== TESTIMONIAL SECTION END ================== */}
      <NewsLetter />
   </>
}

export default Home
