import React from 'react'

const subtitle = ({subtitle}) => {
   return (
      <h3 className='section__subtitle'>{subtitle}</h3>
   )
}

export default subtitle